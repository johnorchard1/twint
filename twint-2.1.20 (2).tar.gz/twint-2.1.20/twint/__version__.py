VERSION = (2, 1, 20)

__version__ = '.'.join(map(str, VERSION))
